---
title: Introduction
description: An introduction to the onboarding tutorial
---

# Starter Tutorial

This is a paragraph about what the tutorial contains.

Here is some code:

```js
function demo() {
  // This is a comment
  console.log('Hello World');
}
```
