---
title: Introduction
description: An introduction to the onboarding tutorial
---

# Starter Tutorial

Follow the steps in the terminal to set up a Vonage application and get the application running.
