---
title: Introduction
description: An introduction to the onboarding tutorial
---

# Starter Tutorial

Follow the steps in the terminal to set up a Vonage application and get the application running.

> You'll get an error after creating the application and starting the server because the routes file is empty. You'll fill in the code in the next step, so just stop the server for now (Ctrl+C or Cmd+C on Mac).